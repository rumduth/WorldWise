import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useCities } from "../contexts/CitiesContext";
import BackButton from "./BackButton";
import styles from "./City.module.css";
import Spinner from "./Spinner";

const formatDate = (date) =>
  new Intl.DateTimeFormat("en", {
    day: "numeric",
    month: "long",
    year: "numeric",
    weekday: "long",
  }).format(new Date(date));

function City() {
  const { id } = useParams();
  const { getCity, currentCity, isLoading, updateCity } = useCities();
  const [isEditing, setIsEditing] = useState(false);
  const [editedNotes, setEditedNotes] = useState("");
  const [newVisitDate, setNewVisitDate] = useState("");
  
  useEffect(
    function () {
      getCity(id);
    },
    [id, getCity]
  );
  
  useEffect(() => {
    if (currentCity?.notes) setEditedNotes(currentCity.notes);
  }, [currentCity]);

  const { cityName, emoji, date, notes, visits = [] } = currentCity;

  function handleEditToggle() {
    setIsEditing(!isEditing);
  }

  function handleSaveNotes() {
    updateCity(id, { notes: editedNotes });
    setIsEditing(false);
  }

  function handleAddVisit() {
    if (!newVisitDate) return;
    
    const updatedVisits = [...(visits || []), { date: newVisitDate }];
    updateCity(id, { visits: updatedVisits });
    setNewVisitDate("");
  }

  if (isLoading) return <Spinner />;

  return (
    <div className={styles.city}>
      <div className={styles.row}>
        <h6>City name</h6>
        <h3>
          <span>{emoji}</span> {cityName}
        </h3>
      </div>

      <div className={styles.row}>
        <h6>You first went to {cityName} on</h6>
        <p>{formatDate(date || null)}</p>
      </div>

      {visits && visits.length > 0 && (
        <div className={styles.row}>
          <h6>Your visits</h6>
          <ul className={styles.visitsList}>
            {visits.map((visit, index) => (
              <li key={index}>{formatDate(visit.date)}</li>
            ))}
          </ul>
        </div>
      )}
      
      <div className={styles.row}>
        <h6>Add a new visit</h6>
        <div className={styles.formRow}>
          <input 
            type="date" 
            value={newVisitDate} 
            onChange={(e) => setNewVisitDate(e.target.value)}
          />
          <button onClick={handleAddVisit} className={styles.btn}>Add</button>
        </div>
      </div>

      <div className={styles.row}>
        <div className={styles.notesHeader}>
          <h6>Your notes</h6>
          <button 
            onClick={handleEditToggle} 
            className={styles.editButton}
          >
            {isEditing ? "Cancel" : "Edit"}
          </button>
        </div>
        
        {isEditing ? (
          <div className={styles.editArea}>
            <textarea
              value={editedNotes}
              onChange={(e) => setEditedNotes(e.target.value)}
              rows={4}
              className={styles.notesTextarea}
            />
            <button 
              onClick={handleSaveNotes} 
              className={styles.btn}
            >
              Save
            </button>
          </div>
        ) : (
          <p>{notes}</p>
        )}
      </div>

      <div className={styles.row}>
        <h6>Learn more</h6>
        <a
          href={`https://en.wikipedia.org/wiki/${cityName}`}
          target="_blank"
          rel="noreferrer"
        >
          Check out {cityName} on Wikipedia &rarr;
        </a>
      </div>

      <div>
        <BackButton />
      </div>
    </div>
  );
}

export default City;