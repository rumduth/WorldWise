To run the application, please follow these steps:

Please make sure that your you should install MongoDB or Compass to your machine
//Running Front end Application
1. npm i
2. npm run dev
//Running Backend
3. cd server
4. npm run dev
